<?php
    session_start();
extract($_POST);
$_SESSION['uname']= $username;
//$_SESSION['password']= $mypassword;

if (isset($_POST["remember"]))
{
    setcookie("username",$_POST["username"], time() + (60*60*24));
    setcookie("password",$_POST["password"], time() + (60*60*24));
}
else
{
    setcookie("username",$_POST["username"], 1);
}
echo "test";
echo $_SESSION['uname'];
header("location:index.php");
?>