<?php
    extract($_POST);
    $sql="insert into my_tab(Name,Email,Password,Contact) values('$name','$email','$psw',$contact)";
    $sql1="Select * from my_tab where Email='$email'";
    $conn=mysqli_connect('pmanaktala.com','pmanakta_db','pmanaktala;');
    if(!$conn) 
    { 
        die("Error connection to database"); 
    }
    $stat=mysqli_select_db($conn,'pmanakta_db');
    if(!$stat) 
    {
         die("Error selecting table"); 
    }
    $result = mysqli_query($conn, $sql1);
    if(!$result) 
    {
     echo "Error executing querry";
    }
    $num= mysqli_num_rows($result);
    
    if($num>0) 
    {
     header("location:register.php?exists");
    }
    else
    {
     $result = mysqli_query($conn, $sql);
     if(!$result)
     {
      echo "Error in inserting the data";
     }
     else
     {
      session_start();
      $_SESSION["email"]=$email;
      $_SESSION["pass"]=$psw;
      header("location:login.php?success");
     }
    }
?>