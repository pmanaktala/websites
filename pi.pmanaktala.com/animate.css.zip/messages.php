<html>
    <head>
        <title>Form</title>
    </head>
<body>
<form name="form1" action="insert.php" method="post" id="form1">
  <input type="text" name="tagid">
  <input type="text" name="name">
  <input type="text" name="quantity">
  <input type="text" name="batch">
  <input type="submit" value="Submit">
</form> 
</body>
</html>
